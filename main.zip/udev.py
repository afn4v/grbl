import os
import shutil
import threading
import time

TARGET_FILENAME = 'grbl.nc'
DEST_DIR = '/home/admin/grbl'
DEST_PATH = os.path.join(DEST_DIR, TARGET_FILENAME)


def _monitor():
    print('Start monitoring USB devices...')
    found = False
    while True:
        if not found:
            for dirpath, _, filenames in os.walk('/run/media/admin'):
                if TARGET_FILENAME in filenames:
                    file = os.path.join(dirpath, TARGET_FILENAME)
                    if os.path.exists(file):
                        found = True
                        try:
                            shutil.copy2(file, DEST_PATH)
                            print(f'The file is copied to {DEST_PATH}')
                        except Exception as e:
                            print(f'Copy error: {e}')
        else:
            if not os.path.exists(file):
                found = False
        time.sleep(5)

# Запускаем мониторинг в отдельном потоке
_handle = threading.Thread(target=_monitor, daemon=True)
_handle.start()