import os
import shutil
import threading
import time
import pyudev

TARGET_FILENAME = 'grbl.nc'
MOUNT_BASE = '/mnt/usb'
DEST_DIR = '/home/admin/grbl'
DEST_PATH = os.path.join(DEST_DIR, TARGET_FILENAME)

# Подготовка папок
os.makedirs(MOUNT_BASE, exist_ok=True)
os.makedirs(DEST_DIR, exist_ok=True)

context = pyudev.Context()
monitor = pyudev.Monitor.from_netlink(context)
monitor.filter_by(subsystem='block', device_type='partition')

def mount_device(device_node):
    # Определяем файловую систему
    try:
        with open(f'/sys/block/{os.path.basename(device_node)}/device/uevent', 'r') as f:
            fstype = next((l.split('=', 1)[1].strip() for l in f if l.startswith('ID_FS_TYPE=')), None)
    except Exception:
        return None

    if not fstype:
        return None

    mount_point = MOUNT_BASE
    try:
        # Монтируем только если не примонтировано
        if not os.path.ismount(mount_point):
            os.system(f'mount -t {fstype} {device_node} {mount_point}')
        return mount_point
    except Exception as e:
        print(f'Mounting error: {e}')
        return None

def unmount_device():
    try:
        if os.path.ismount(MOUNT_BASE):
            os.system(f'umount {MOUNT_BASE}')
    except Exception as e:
        print(f'Unmounting error: {e}')

def find_and_copy():
    src_path = os.path.join(MOUNT_BASE, TARGET_FILENAME)
    if os.path.isfile(src_path):
        try:
            shutil.copy2(src_path, DEST_PATH)
            print(f'The file is copied to {DEST_PATH}')
        except Exception as e:
            print(f'Copy error: {e}')
    else:
        print('The grbl.nc file is not found in the root of the flash drive.')

def _monitor():
    print('Start monitoring USB devices...')
    for device in iter(monitor.poll, None):
        if device.action == 'add':
            print(f'Device detected: {device.device_node}')
            mount_point = mount_device(device.device_node)
            if mount_point:
                print(f'The device is mounted in {mount_point}')
                find_and_copy()
                unmount_device()
                print('The device is unmounted')

# Запускаем мониторинг в отдельном потоке
_handle = threading.Thread(target=_monitor, daemon=True)
_handle.start()