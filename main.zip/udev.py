import os
import shutil
import threading
import pyudev

TARGET_FILENAME = 'grbl.nc'
DEST_DIR = '/home/admin/grbl'
DEST_PATH = os.path.join(DEST_DIR, TARGET_FILENAME)

os.makedirs(DEST_DIR, exist_ok=True)
context = pyudev.Context()
monitor = pyudev.Monitor.from_netlink(context)
monitor.filter_by(subsystem='block', device_type='partition')

def find_grbl_nc_in_root(device):
    try:
        devname = os.path.basename(device.device_node)
        with open(f'/sys/block/{devname}/device/uevent', 'r') as f:
            for line in f:
                if line.startswith('DEVPATH='):
                    devpath = line.split('=', 1)[1].strip()
                    break
            else:
                return None
    except Exception:
        return None

    mount_point = None
    try:
        with open('/proc/mounts', 'r') as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2 and devpath in parts[0]:
                    mount_point = parts[1]
                    break
    except Exception:
        pass

    if not mount_point:
        return None

    target_path = os.path.join(mount_point, TARGET_FILENAME)
    return target_path if os.path.isfile(target_path) else None

def _monitor():
    print('🔍 Старт мониторинга USB-устройств...')
    for device in iter(monitor.poll, None):
        if device.action == 'add':
            src_path = find_grbl_nc_in_root(device)
            if src_path:
                print(f'📎 Найден файл: {src_path}')
                try:
                    shutil.copy2(src_path, DEST_PATH)
                    print(f'✅ Файл скопирован в {DEST_PATH}')
                except Exception as e:
                    print(f'❌ Ошибка при копировании: {e}')
            else:
                print('⚠️ Файл grbl.nc не найден в корне этой флешки.')

# Запускаем мониторинг в отдельном потоке
_handle = threading.Thread(target=_monitor, daemon=True)
_handle.start()