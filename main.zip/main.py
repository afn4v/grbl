import re
import sys

import serial
import serial.tools.list_ports
import time

if sys.platform != 'win32':
    import udev

def send(device: serial.Serial, command: str) -> str | None:
    """Отправляет команду устройству и возвращает ответ."""
    resp: str = ''
    if not device or not device.is_open:
        return None
    try:
        device.reset_input_buffer()
        device.write(f'{command}\n'.encode())
        start_time = time.time()
        while True:
            if device.in_waiting > 0:
                line = device.readline().decode(errors='ignore')
                resp += line
                if 'ok' in resp or 'error' in resp:
                    break
            time.sleep(0.01)
    except Exception as e:
        print(f'Ошибка при отправке команды на {device.port}:', e)
    return resp.strip() or None

def check(port: str) -> bool:
    checked: bool = False
    try:
        with serial.Serial(port, 115200, timeout=1) as device:
            data: str | None = send(device, '$I')
            if data and ('VER' in data.upper()):
                checked = True
    except (serial.SerialException, OSError) as e:
        # Ошибки открытия порта (занят, не существует) игнорируем
        pass
    except Exception as e:
        print(f'Неизвестная ошибка при проверке {port}:', e)
    return checked

def main():

    # Множество для хранения активных портов
    devices = set()
    
    while True:
        
        ports = {port.device for port in serial.tools.list_ports.comports()}
            
        if len(devices) == 0:
            for port in ports:
                if port not in devices:
                    if check(port):
                        print(f"Устройство найдено: {port}")
                        devices.add(port)
                        with serial.Serial(port, 115200, timeout=1) as device:
                            with open('./demo.nc', 'r') as f:
                                for line in f:
                                    
                                    # --- ФИЛЬТРАЦИЯ КОММЕНТАРИЕВ ---
                                    # 1. Удаляем все, что после точки с запятой (включая её)
                                    line = line.split(';', 1)[0]
                                    
                                    # 2. Удаляем все, что внутри круглых скобок (включая их)
                                    line = re.sub(r'$.*?$', '', line)
                                    
                                    # Убираем пробелы по краям и переводим в нижний регистр
                                    l = line.strip().lower()
                            
                                    if not l: 
                                        continue
                                    
                                    data: str | None = send(device, l)
                                    if data:
                                        if 'ok' in data:
                                            continue
                                        elif 'error' in data:
                                            for err in data.split('\n'):
                                                if err:
                                                    print(f"ERR: {err}")
                                            break
                                    else:
                                        break
                
        disconnected = devices - ports         
        for port in disconnected:
            print(f"Устройство отключено: {port}")
            devices.remove(port)
            
        time.sleep(0.1)

if __name__ == "__main__":
    main()
